class Faction:
    ACADEMY = 0
    RENEGADES = 1
    NEUTRAL = 2
    OTHER = 3
