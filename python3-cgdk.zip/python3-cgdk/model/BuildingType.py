class BuildingType:
    GUARDIAN_TOWER = 0
    FACTION_BASE = 1
