class StatusType:
    BURNING = 0
    EMPOWERED = 1
    FROZEN = 2
    HASTENED = 3
    SHIELDED = 4
