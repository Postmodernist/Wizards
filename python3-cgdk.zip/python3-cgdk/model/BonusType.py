class BonusType:
    EMPOWER = 0
    HASTE = 1
    SHIELD = 2
